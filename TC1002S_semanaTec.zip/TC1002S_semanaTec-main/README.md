# TC1002S_semanaTec
Semana Tec TC1002S: Herramientas computacionales
